# Amazfit GTR 4 Watchface

Forked from https://amazfitwatchfaces.com/gtr/view/39136 which was originally forked from https://amazfitwatchfaces.com/t-rex/view/13548.

## Installation

## Contributing

I'd love to see your contributions to this project. Feel free to fork it and submit a pull request.

Here are some ideas for contributions:

- fix: we should be able to run `zeus preview` but it fails with error "Please set at least one package"
- feat: add a script to automate the generation of a QR code for the watchface
- chore: improve the readme to explain how to live preview the watchface
- chore: rename images to more meaningful names, instead of just numbers
