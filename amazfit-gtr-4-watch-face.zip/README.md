# Amazfit GTR 4 Watchface

Forked from https://amazfitwatchfaces.com/gtr/view/39136 which was originally forked from https://amazfitwatchfaces.com/t-rex/view/13548.

## Installation

## Contributing

I'd love to see your contributions to this project. Feel free to fork it and submit a pull request.

Here are some ideas for contributions:

- Add a script to automate the generation of a QR code for the watchface
